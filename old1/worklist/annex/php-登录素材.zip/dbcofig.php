<?php
$dbtype = "mysql";
$dbhost = "localhost";
$dbname = 'gdmec';
$dbcharset = 'gbk';
$dbusername = 'root';
$dbpassword = '';


header("content-type:text/html;charset=gbk");
$dsn="$dbtype:host=$dbhost;dbname=$dbname;charset=$dbcharset";  
try{  
    $pdo = new PDO($dsn,$dbusername,$dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){  
    exit('���ݿ�����ʧ��'.$e->getMessage());  
}  
?>