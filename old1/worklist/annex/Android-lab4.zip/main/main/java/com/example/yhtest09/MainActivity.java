package com.example.yhtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    // 1. 在对应的布局文件中设置控件的id属性

    // 2. 在当前活动类（MainActivity) 中定义控件变量
    TextView tvUser, tvEquip, tvLife, tvAttack, tvSpeed;
    Button btSelect1, btSelect2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 3. 在活动初始化方法（onCreat(...)）中进行控件变量初始化
        tvUser  = (TextView) findViewById(R.id.txtUser);
        tvEquip = (TextView) findViewById(R.id.txtEquip);
        tvLife  = (TextView) findViewById(R.id.txtLife);
        tvAttack = (TextView) findViewById(R.id.txtAttack);
        tvSpeed  = (TextView) findViewById(R.id.txtSpeed);
        btSelect2 = (Button) findViewById(R.id.btn2);

        // 部分显示内容初始化
        tvUser.setText("MyName");
        tvEquip.setText("未选装备");

        // 4. 绑定事件过程，并编写事件方法（有4种方法，此处只用匿名类法）
        btSelect2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.i("Info","OKKKK");
                Intent intent = new Intent(MainActivity.this, ShopActivity2.class);
                startActivityForResult(intent, 1); // 返回请求结果,请求码为1
                //Log.i("Info","OKKKK2");
            }
        });
    }

    // 5 编写返回处理代码
    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            // 判断结果码是否等于1,等于1为宝宝添加装备
            if (resultCode == 1) {
                if (requestCode == 1) {
                    ItemInfo info =
                            (ItemInfo) data.getSerializableExtra("equipment");
                    tvUser.setText("MyName");
                    tvEquip.setText( info.getEquipment() );
                    // 注意：整数必须转换成字符串赋值，单一整数作参数只表示资源号：
                    //  setText( int resid ）； resid 只是资源号
                    tvLife.setText( String.valueOf( info.getLife() ) );
                    tvAttack.setText( String.valueOf( info.getAttack() ) );
                    tvSpeed.setText(( String.valueOf(info.getSpeed() ) ) );
                    //更新ProgressBar的值
                    //updateProgress(info);
                }
            }
        }
    }

}
