<?php 
include_once 'mail.inc.php';
if(isset($_REQUEST['email'])){
	$mailto = $_REQUEST['email'];
	$mailsubject = $_REQUEST['subject'];
	$mailfrom = "huzejun@sina.com";
	$mailbody = $_REQUEST['content'];
	sendmail($mailto,$mailsubject,$mailfrom,$mailbody);
	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>发送邮件测试</title>
<style type="text/css">
<!--
body {
	background-color: #336699;
}

.framecenter {
	width: 800px;
	margin-top: 100px;
	margin-right: auto;
	margin-bottom: 0px;
	margin-left: auto;
	background-color: #FFFFFF;
	padding: 15px;
}

body,td,th {
	font-size: 12px;
	color: #666666;
}

.spantitle {
	font-size: 14px;
	font-weight: bold;
	text-align: center;
}
-->
</style>
</head>
<body>
	<div class="framecenter">
		<div class="fup">
			<span class="spantitle">PHP表单邮件发送广东机电版</span>
		</div>
		<div class="fdown"></div>
		<div class="fcontent lineheight150">
			<form name="contactForm" method="post" action="contact.php"
				target="ifrm">
				<table width="100%">
					<tr>
						<td><table width="100%" border="0" cellspacing="0" cellpadding="5">
								<tr bgcolor="#F5F0DA">
									<td bgcolor="#FFFFFF">收件人地址*</td>
									<td bgcolor="#FFFFFF"><input name="email" type="text"
										id="email" size="66" maxlength="100" /></td>
								</tr>
								<tr bgcolor="#F5F0DA">
									<td bgcolor="#FFFFFF">邮件主题*</td>
									<td bgcolor="#FFFFFF"><input name="subject" type="text"
										id="email" size="66" maxlength="100" /></td>
								</tr>
								<tr bgcolor="#F5F0DA">
									<td bgcolor="#FFFFFF">邮件内容*</td>
									<td bgcolor="#FFFFFF"><textarea name="content" cols="50" rows="3"></textarea>
									</td>
								</tr>
								<tr>
									<td height="50" colspan="2"><input name="submit" type="submit"
										value="提交" /> <input name="reset" type="reset" value="重置" /></td>
								</tr>
							</table></td>
					</tr>
				</table>
				<input name="user" type="hidden" id="user" value="johnny_zhou" /><input
					name="formid" type="hidden" id="formid" value="351745" /><input
					name="subject" type="hidden" id="subject" value="Cleaning Enquiry" />
			</form>
		</div>
	</div>
	<iframe frameborder=0 width="0" height="0" src="" scrolling="no"
		name="ifrm" ID="ifrm"></iframe>
</body>
</html>