package com.example.yhtest09;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class ShopActivity2 extends AppCompatActivity {

    // 可选装备数目
    int EQ_NUM = 3;
    int ADDTION = 4;

    // 当前所选的TextView， 用于显示背景光带（不同的背景色）
    // 注：两个控件变量可以引用同一个控件“实体”，变量只是一种引用，没引用时，为null
    private  TextView curSelView;

    // 当前所选的ItemInfo的索引
    private  int curSelIndex;

    // ItemInfo 用于存放所有的可选装备及其相关信息
    // 注：数组本身是一种对象，而数组元素又是另一种对象，
    // 这里new所定义的是数组本身，所以后面还要定义每一个元素
    private ItemInfo items[] = new ItemInfo[EQ_NUM];

    // 事件编程--1. 在布局文件(activity_shop2.xml)中定义相关控件的id值，如：
    //     <Button
    //            android:id = "@+id/btn3"
    //            ...
    //     其中btn3即为对应的控件标识名，但程序中用的是控件变量名，如下：

    // 事件编程--2. 定义控件变量，代码中通过控件变量来操作控件本身的外观及行为。
    Button btSelect3;
    // 同样，也可定义控件数组，本例中，将所有显示控件信息的TextView都组织成一个数组，便于遍历访问
    TextView tvs[] = new TextView[EQ_NUM];
    CheckBox cbs[] = new CheckBox[ADDTION];

    // 当前所选的装备改变时，界面上的处理（即改变相关的背景色，实现光带的效果）
    private void changeItem( int idx ) {
        // 如果当前所选的TextView 不为空（第一次进入该界面时可能为空），才恢复原来背景
        if ( curSelView != null ){
            curSelView.setBackgroundColor(Color.YELLOW);
        }
        // 用新选的TextView替换老的引用
        curSelView = tvs[idx];
        // 记录新选项的索引号（即数组下标）
        curSelIndex = idx;
        // 将当前所选项换成新的背景色（以实现光带效果）
        curSelView.setBackgroundColor(Color.RED);
        // 刷新增益属性
        refreshSeledItem( idx );
    }

    private  void refreshSeledItem( int idx ){
        cbs[0].setChecked( items[idx].getUseTreat() );
        cbs[1].setChecked( items[idx].getUseImmune() );
        cbs[2].setChecked( items[idx].getUseChaos() );
        cbs[3].setChecked( items[idx].getUseDizzy() );
    }

    // 初始化装备数据，将来可改为从数据库或文件读。
    private void initItems() {
        items[0] = new ItemInfo("七星剑", 8100,2100,1100);
        items[1] = new ItemInfo("龙泉剑", 8200,2200,1200);
        items[2] = new ItemInfo("青龙偃月刀", 8300,2300,1300);

        items[0].setUseTreat( true );
        items[0].setUseDizzy( true );
        items[1].setUseTreat( true );
        items[2].setUseImmune( true );
    }

    // 获取某（编号为idx）装备的基本信息描述串（用于输出）
    private String getEquipInfo( int idx ) {
       int i = 0;
       String result = "";
       result += "生命值："+ String.valueOf( items[idx].getLife() ) + "  ";
       result += "攻击力："+ String.valueOf( items[idx].getAttack() ) + "  ";
       result += "敏捷："+ String.valueOf( items[idx].getSpeed() ) + "  ";
       return result;
    }

    // 刷新所选装备的信息
    private void refreshEquipInfo() {
        tvs[0].setText( getEquipInfo( 0));
        tvs[1].setText( getEquipInfo( 1));
        tvs[2].setText( getEquipInfo( 2));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop2);

        // 事件编程--3. 初始化控件变量
        // 即将控件变量与布局文件中定义的控件关联；否则，控件变量值为空（null），会出错
        tvs[0]  = (TextView) findViewById(R.id.txtEquip1);
        tvs[1]  = (TextView) findViewById(R.id.txtEquip2);
        tvs[2]  = (TextView) findViewById(R.id.txtEquip3);
        btSelect3 = (Button) findViewById(R.id.btn3);

        cbs[0] = (CheckBox) findViewById(R.id.checkBox1);
        cbs[1] = (CheckBox) findViewById(R.id.checkBox2);
        cbs[2] = (CheckBox) findViewById(R.id.checkBox3);
        cbs[3] = (CheckBox) findViewById(R.id.checkBox4);

        // 数据处理代码--1.初始化装备数据，调用本类实现的私有方法完成
        initItems();

        // 数据处理代码--2.初始化界面数据，调用本类实现的私有方法完成
        refreshEquipInfo();

        // 事件编程--4. 绑定并编写事件过程
        btSelect3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("equipment", items[curSelIndex] );
                setResult(1,intent);
                finish();
            }
        });

        // 当选中该项时，通过背景色轮换，以实现光带效果（下同）
        tvs[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( 0 );
            }
        });
        tvs[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( 1);
            }
        });
        tvs[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( 2);
            }
        });
    }
}