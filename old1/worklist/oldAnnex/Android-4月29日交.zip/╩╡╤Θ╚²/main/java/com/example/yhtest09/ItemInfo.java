package com.example.yhtest09;

import java.io.Serializable;

public class ItemInfo implements Serializable {

    private  String equipment;
    private  int life;
    private  int attack;
    private  int speed;

    // 增加增益属性
    private boolean useTreat = false;     // 治疗
    private boolean useImmune = false;   // 免疫
    private boolean useChaos = false;    // 混乱
    private boolean useDizzy = false;    // 晕眩

    // 通过构造函数初始化各属性
    ItemInfo( String equipment, int life, int attack, int speed){
       this.equipment = equipment;
       this.life = life;
       this.attack = attack;
       this.speed = speed;
    }

    public String getEquipment(){
        return equipment;
    }
    public int getLife(){
        return life;
    }
    public int getAttack(){
        return attack;
    }
    public int getSpeed(){
        return speed;
    }

    // 一个完整的数据类既可以通过构造函数传入参数初始化，也可通过一系列的set方法初始化
    public void setEquipment( String equipment ) {
        this.equipment = equipment;
    }

    public void setLife( String equipment ) {
        this.equipment = equipment;
    }

    public void setAttack( int attack ) {
        this.attack = attack;
    }

    public void setSpeed( int speed ) {
        this.speed = speed;
    }

    // 增益属性的读写
    public boolean getUseTreat(){
        return useTreat;
    }
    public boolean getUseImmune(){
        return useImmune;
    }
    public boolean getUseChaos(){
        return useChaos;
    }
    public boolean getUseDizzy(){
        return useDizzy;
    }

    // 一个完整的数据类既可以通过构造函数传入参数初始化，也可通过一系列的set方法初始化
    public void setUseTreat( boolean useTreat ) {
        this.useTreat = useTreat;
    }

    public void setUseImmune( boolean useImmune ) {
        this.useImmune = useImmune;
    }

    public void setUseChaos( boolean chaos ) {
        this.useChaos = chaos;
    }

    public void setUseDizzy( boolean useDizzy ) {
        this.useDizzy = useDizzy;
    }

}
