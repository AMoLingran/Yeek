package com.example.yhequipment;

import java.io.Serializable;

public class ItemInfo implements Serializable {

    private  String equipment;
    private  int life;
    private  int attack;
    private  int speed;

    public String getEquipment(){
        return equipment;
    }
    public int getLife(){
        return life;
    }
    public int getAttack(){
        return attack;
    }
    public int getSpeed(){
        return speed;
    }

    public void setEquipment( String equipment ) {
        this.equipment = equipment;
    }
}
