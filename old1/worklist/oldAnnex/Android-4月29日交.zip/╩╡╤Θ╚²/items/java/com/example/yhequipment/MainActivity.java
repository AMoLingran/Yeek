package com.example.yhequipment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    // 1. 在对应的布局文件中设置控件的id属性（）
    // 2. 在当前活动类（MainActivity) 中定义控件变量
    TextView tvUser, tvEquip, tvLife, tvAttack, tvSpeed;
    Button btSelect1, btSelect2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 3. 在活动初始化方法（onCreat(...)）中进行控件变量初始化
        tvUser  = (TextView) findViewById(R.id.txtUser);
        tvEquip = (TextView) findViewById(R.id.txtEquip);
        tvLife  = (TextView) findViewById(R.id.txtLife);
        tvAttack = (TextView) findViewById(R.id.txtAttack);
        tvSpeed  = (TextView) findViewById(R.id.txtSpeed);
        btSelect2 = (Button) findViewById(R.id.btn2);

        // 4. 绑定事件过程，并编写事件方法（有4种方法，此处只用匿名类法）
        btSelect2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShopActivity2.class);
                startActivityForResult(intent, 1); // 返回请求结果,请求码为1
            }
        });
    }


}
