package com.example.yhequipment;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ShopActivity2 extends AppCompatActivity {

    TextView tvEq1, tvEq2, tvEq3;
    Button btSelect3;

    TextView curSelView;

    private void changeItem( TextView selView ) {
        if ( curSelView != null ){
            curSelView.setBackgroundColor(Color.YELLOW);
        }
        curSelView = selView;
        curSelView.setBackgroundColor(Color.RED);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop2);

        tvEq1  = (TextView) findViewById(R.id.txtEquip1);
        tvEq2  = (TextView) findViewById(R.id.txtEquip2);
        tvEq3  = (TextView) findViewById(R.id.txtEquip3);
        btSelect3 = (Button) findViewById(R.id.btn3);

        btSelect3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        tvEq1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( tvEq1);
            }
        });

        tvEq2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( tvEq2);
            }
        });
        tvEq3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeItem( tvEq3);
            }
        });

    }

}
